var app = angular.module("ApioApplication*_TMP_*", ["apioProperty"]);
app.controller("defaultController", ["$scope", "currentObject", function ($scope, currentObject) {
    $scope.object = currentObject.get();
    console.log("Sono il defaultController e l'oggetto è: ", $scope.object);
}]);

setTimeout(function () {
    angular.bootstrap(document.getElementById("ApioApplication*_TMP_*"), ["ApioApplication*_TMP_*"]);
}, 10);
